<?php
include_once('laminates.php');

if(isset($_POST['submit']))
{
    $uname=$_POST['username'];
    $phn=$_POST['phone'];
    $eml=$_POST['email'];
}
$sql="insert into check_availibility(name,phone,email) values('$uname','$phn','$eml')";
$result=mysqli_query($con,$sql);
if($result)
echo"inserted";
else
echo"not inserted";
?>