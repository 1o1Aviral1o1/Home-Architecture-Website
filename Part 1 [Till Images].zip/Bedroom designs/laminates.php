<?php
 $server='localhost';
 $user='root';
 $pwd='';
 $db='check_avail';

 $con=mysqli_connect($server,$user,$pwd,$db);
 if($con)
   echo"connected";
else
   echo"not connected";

?>