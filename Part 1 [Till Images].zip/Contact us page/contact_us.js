// alert("the file is working");

function myfun(){

    var a= document.contact_us.checkbo;
    for (i = 0; i < a.length; i++) {
        if (a[i].checked==true)
            return true;
    }
    document.getElementById("terms").innerHTML="**You must agree with our terms";
    return false;
}

// {
//     var valid= false;
//     if(document.getElementById("terms").checked){
//         valid=true;
//     }

// }
