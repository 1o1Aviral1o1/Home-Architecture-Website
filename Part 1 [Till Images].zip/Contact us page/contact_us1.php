<?php

include_once('contact_us.php');

if(isset($_POST['submit']))
{

$uname=$_POST['username'];
$ph=$_POST['phonenumber'];
$em=$_POST['email'];
$fdbk=$_POST['feedback'];

}
$sql="insert into contact_us(user,userphone,useremail,userfeedback)values('$uname','$ph','$em','$fdbk')";
$result=mysqli_query($con,$sql);
if($result)
echo"inserted";
else
echo"not inserted";
?>