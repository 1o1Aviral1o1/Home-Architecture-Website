<?php
 $server='localhost';
 $user='root';
 $pwd='';
 $db='login';
 $con=mysqli_connect($server,$user,$pwd,$db);
 if($con)
   echo"connected";
else
   echo"not connected";

?>